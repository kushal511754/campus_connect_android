package com.example.campus_connect_android

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
